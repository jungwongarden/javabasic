package �������̽�;

public class MelonPhone implements MultiPhone {

	@Override
	public void internet() {
		// TODO Auto-generated method stub

	}

	@Override
	public void call() {
		// TODO Auto-generated method stub

	}

	@Override
	public void text() {
		// TODO Auto-generated method stub

	}

	@Override
	public void kakao() {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyboard() {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouse() {
		// TODO Auto-generated method stub

	}

	@Override
	public void picture() {
		// TODO Auto-generated method stub

	}

}
